	
	update InterfazSalida set TipoFecha=3 where INSTipoInterfaz=51
	
	update AbnTrp set TipoFaseIntSal = 1