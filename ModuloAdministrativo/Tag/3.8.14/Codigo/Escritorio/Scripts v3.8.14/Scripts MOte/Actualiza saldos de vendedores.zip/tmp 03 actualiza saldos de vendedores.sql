
delete from vendedoressaldos where fecha > '20100331'

update vendedoressaldos 
set saldoanterior = 0
where saldoanterior is null

update vendedoressaldos 
set saldoactual = saldoanterior + saldo
where saldoactual  is null

delete
from vendedoressaldos 
where fecha = '20100331' and idvendedor in (29, 30)
and saldoactual > 0

declare @IdCedis as bigint, @IdSurtido as bigint, @IdVendedor as bigint, @Fecha as datetime

			declare  ActPrecio cursor for
				select Surtidos.IdCedis, Surtidos.IdSurtido, Surtidos.Fecha, SurtidosVendedor.IdVendedor
				from Surtidos 
				inner join SurtidosVendedor on Surtidos.IdCedis = SurtidosVendedor.IdCedis and Surtidos.IdSurtido = SurtidosVendedor.IdSurtido 
				where Surtidos.Fecha > '20100331' -- and Surtidos.Fecha <= '20100401'
				order by Surtidos.IdCedis, Surtidos.IdSurtido, Surtidos.Fecha
			open ActPrecio
			
			fetch next from ActPrecio into @IdCedis, @IdSurtido, @Fecha, @IdVendedor 
			while (@@fetch_status = 0)
			begin
				exec up_VendedoresSaldos @IdCedis, @IdSurtido, @IdVendedor, @Fecha, 1 

				fetch next from ActPrecio into @IdCedis, @IdSurtido, @Fecha, @IdVendedor 
			end
			close ActPrecio
			deallocate ActPrecio		

