package org.xmlcomparator.saxEvents;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */

public class StartDocument extends Event {

    public StartDocument( int depth ) {
        setDepth(depth);
    }

    public boolean compare(Event event) {
        if (!(event instanceof StartDocument)||!compareDepth(event))
            return false;
        return true;
    }

    public String  toString() {
        return "";
    }

    public String getType() {
        return "[start document]";
    }

}