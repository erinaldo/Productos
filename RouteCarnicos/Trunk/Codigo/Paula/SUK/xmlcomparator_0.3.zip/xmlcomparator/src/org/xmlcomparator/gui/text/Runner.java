package org.xmlcomparator.gui.text;

import  java.io.FileWriter;
import  java.io.PrintWriter;

import org.xmlcomparator.gui.XMLTreeModel;
import org.xmlcomparator.SaxComparator;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author unascribed
 * @version 1.0
 */

public class Runner {

    public Runner() {
    }

    public static void main(String[] argv) {
        if (argv.length != 2) {
            System.out.println("Usage: java SaxComparator [URI1] [URI2]");
            System.exit(0);
        }

        try {
            String uri1 = argv[0];
            String uri2 = argv[1];

            int nbdiff = 0;


            FileWriter file1 = new FileWriter(uri1+".diffresult");
            FileWriter file2 = new FileWriter(uri2+".diffresult");
            TreeLogger tree1 = new TreeLogger(new PrintWriter(file1,true));
            TreeLogger tree2 = new TreeLogger(new PrintWriter(file2,true));

            SaxComparator comparator = new SaxComparator();
            comparator.setGui(uri1,tree1);
            comparator.setGui(uri2,tree2);
            comparator.setStopAtFirstDiff(false);



//            int nbdiff = comparator.doCompare(uri1,uri2);

            nbdiff = comparator.doCompare(uri1,uri2);


            if (nbdiff==0) {
                System.out.println(uri1+" and "+uri2+" seem to be equivalent");
            } else {
                System.out.println(nbdiff+" differences were detected between "+uri1+" and "+uri2);
            }

            tree1._output.flush();
            tree2._output.flush();
            tree1._output.close();
            tree2._output.close();



        } catch ( Exception e ) {
            e.printStackTrace();
        }


    }
}