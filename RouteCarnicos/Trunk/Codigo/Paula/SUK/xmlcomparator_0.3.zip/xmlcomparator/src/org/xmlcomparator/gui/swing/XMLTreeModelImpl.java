package org.xmlcomparator.gui.swing;

import  java.util.StringTokenizer;
import  java.util.HashMap;
import  java.lang.StringBuffer;
import  javax.swing.tree.DefaultTreeModel;
import  javax.swing.tree.DefaultMutableTreeNode;
import  javax.swing.tree.TreeNode;

import  org.xmlcomparator.gui.XMLTreeModel;
import  org.xmlcomparator.saxEvents.Event;
import  org.xmlcomparator.saxEvents.Characters;
import  org.xmlcomparator.saxEvents.EndDocument;
import  org.xmlcomparator.saxEvents.EndElement;
import  org.xmlcomparator.saxEvents.StartDocument;
import  org.xmlcomparator.saxEvents.StartElement;

/**
 * <p>XML Tree Model for the swing gui.</p>
 * <p>This class is used to make
 * the connexion between the diff engine
 * and the swing gui.</p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */
public class XMLTreeModelImpl implements XMLTreeModel {

    /** The swing tree model that will be dispayed */
    DefaultTreeModel _swingTree = null;

    /** the current node in the swing tree model */
    DefaultMutableTreeNode _currentNode = null;

    public XMLTreeModelImpl() {
    }

    /**
     * Method used by the diff engine to build the tree.
     * @param event         the sax events
     * @param diffDetected  a boolean that indicate if a diff
     *                      have been detected with the sax event.
     */
    public void addNode(Event event, boolean diffDetected) {


        if (event instanceof StartDocument) {
            _currentNode =  new DefaultMutableTreeNode("<html><b>root of the tree</b></html>");
        } else if (event instanceof StartElement) {
            DefaultMutableTreeNode newNode =
                new DefaultMutableTreeNode(new XMLTreeNode(event,diffDetected));
            _currentNode.add(newNode);
             _currentNode = newNode;
        } else if (event instanceof Characters) {
            DefaultMutableTreeNode newNode =
                new DefaultMutableTreeNode(new XMLTreeNode(event,diffDetected));
            _currentNode.add(newNode);
        } else if (event instanceof EndElement) {
            _currentNode = (DefaultMutableTreeNode)_currentNode.getParent();
        } else if (event instanceof EndDocument) {
            _swingTree = new DefaultTreeModel(_currentNode.getFirstChild());
        }
    }

    /**
     * Method used by the GUI to retrieve the swing tree model
     * @return  the DefaultTreeModel representing the xml document
     */
    public DefaultTreeModel getSwingTreeModel() {
        return _swingTree;
    }
}