package org.xmlcomparator.saxEvents;

/**
 * Base class of on object representation
 * of sax events.
 * @author Alexandre Victoor
 * @version 1.0
 */
public abstract class Event {


    /**
     *  depth in the tree of the element
     *  corresponding to the event
     */
    private int _depth = 0;

    public void setDepth( int depth ) {
        _depth = depth;
    }

    public int getDepth() {
        return _depth;
    }

    public boolean compareDepth( Event event ) {
        return (_depth==event.getDepth());
    }

    public String getType() {
        return "";
    }

    abstract public boolean compare( Event event );


}