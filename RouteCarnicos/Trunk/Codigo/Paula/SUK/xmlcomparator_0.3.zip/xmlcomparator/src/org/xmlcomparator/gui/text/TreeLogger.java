package org.xmlcomparator.gui.text;

import  java.io.PrintWriter;

import  org.xmlcomparator.gui.XMLTreeModel;
import  org.xmlcomparator.saxEvents.Event;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */

public class TreeLogger implements XMLTreeModel {

    PrintWriter _output = null;

    public TreeLogger(PrintWriter output) {
        _output = output;
    }

    public void addNode(Event event, boolean diff) {

        _output.print(event);
        if (diff) {

            _output.print(" <!-- ");
            _output.print(event.getType());
            _output.print(" different");
            _output.print(" -->");
        }

    }

}