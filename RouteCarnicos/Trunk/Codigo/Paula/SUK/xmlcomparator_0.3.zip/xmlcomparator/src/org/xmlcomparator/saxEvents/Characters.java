package org.xmlcomparator.saxEvents;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author unascribed
 * @version 1.0
 */

public class Characters extends Event {

    String _text = "";

    public String getText() {
        return _text;
    }

    public Characters(String text, int depth) {
        _text = text;
        setDepth(depth);
    }

    public boolean compare(Event event) {
        if (!(event instanceof Characters)||(!compareDepth(event)))
            return false;
        return compareValues(event);
    }

    boolean compareValues(Event event) {
        Characters characters = (Characters)event;
        return (_text.equals(characters.getText()));
    }

    public String  toString() {
        return _text;
    }
    public String getType() {
        return "[characters]";
    }



}