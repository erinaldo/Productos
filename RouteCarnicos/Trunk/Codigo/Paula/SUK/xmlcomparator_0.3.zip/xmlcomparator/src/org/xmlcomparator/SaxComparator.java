package org.xmlcomparator;

import java.io.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

import  java.util.Vector;
import  java.util.Hashtable;
import  org.xmlcomparator.saxEvents.Event;

import  org.xmlcomparator.gui.XMLTreeModel;

/**
 * The handler used by the
 * sax parsers. One instances
 * of this class should be used by
 * two parsers corresponding
 * to the 2 xml sources. Each event of
 * each handler is compared.
 * @author Alexandre Victoor
 * @version 1.0
 */
public class SaxComparator {


//    public  Vector  _evtVector = new Vector();
    public boolean _diffDetected = false;

    /** table containing the gui objetcs corresponding to the documents compared */
    public Hashtable _treeGuiTable = new Hashtable();

    /* table containing the vectors of events ( one vector per uri )  **/
    public Hashtable _evtVectorTable = new Hashtable();

    /* table of correspondance between uris **/
    public Hashtable _uriTable = new Hashtable();

    /** flag that indicate if we stop at the first difference detected */
    private boolean _stopAtFirstDiff = true;

    /** used to count the number of differences detected */
    private int _diffcounter = 0;


    /**
     * set a gui to a URI
     * @param uri the uri of a document
     * @param tree the tree gui represantation of the document
     */
    public void setGui(String uri, XMLTreeModel tree) {
        _treeGuiTable.put(uri,tree);
    }

    /**
     *
     * @return the flag _stopAtFirstDiff
     */
    public boolean getStopAtFirstDiff() {
        return _stopAtFirstDiff;
    }

    /**
     * set the flag _stopAtFirstDiff.
     * Default value is true.
     * @param stopAtFirstDiff
     */
    public void setStopAtFirstDiff(boolean stopAtFirstDiff) {
        _stopAtFirstDiff = stopAtFirstDiff;
    }

    /**
     * Compare the last event received by an
     * handler with the last event received by
     * the other handler. If the other handler
     * hasn't received an event, wait till so.
     * If the flag _stopAtFirstDiff hase been set
     * to false, the code is more complex. When a
     * difference s detected, the events are saved
     * in 2 vectors, one per uri, in order to
     * compare them laters.
     *
     *
     * @param event the event to compare.
     * @param uri   the uri associated with the
     *              event's xml document
     * @return true if the events received by the two
     *              handlers are equivalent ( makes sense
     *              only if the flag _stopAtFirstDiff is set
     *              to true ).
     */
    public synchronized boolean compareEvent(Event event, String uri) {

//        System.out.println("*********** debut "+event);


        // don't remember why it is needed
        if (_diffDetected&&_stopAtFirstDiff)
            return false;

        Vector thisUriEvtVector = (Vector)_evtVectorTable.get(uri);
        Vector otherUriEvtVector = (Vector)_evtVectorTable.get(_uriTable.get(uri));

        if (otherUriEvtVector.isEmpty()) {
            thisUriEvtVector.add(event);
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
                _diffDetected = true;
            }
        } else {

            String otherUri = (String) _uriTable.get(uri);
            Event otherEvent = (Event) otherUriEvtVector.firstElement();

            _diffDetected = _diffDetected || !event.compare(otherEvent);

            if (_diffDetected) {
                if (_stopAtFirstDiff) {
                    System.out.println("The two following sax events seems different: ");
                    System.out.println(event);
                    System.out.println(otherEvent);
                    otherUriEvtVector.remove(otherEvent); // why ??
                    updateGui(event, uri, _diffDetected);
                } else { // the tricky code is here


//                    System.out.println("otherUriEvtVector.size() "+otherUriEvtVector.size());
                    for (int i=0; (i<otherUriEvtVector.size())&&(_diffDetected); i++) {
//                        System.out.println("dans la boucle principale");
                        Event otherEvent2 = (Event) otherUriEvtVector.elementAt(i);
                        if (event.compare(otherEvent2)) {

                            for (int j=0; j<i; j++) {
                                Event otherEvent3 = (Event) otherUriEvtVector.firstElement();
//                                System.out.println("###########boucle j "+otherEvent3);
                                updateGui(otherEvent3, otherUri, _diffDetected);
                                otherUriEvtVector.remove(0);
                            }

                            while(thisUriEvtVector.size()>0) {
                                Event otherEvent3 = (Event) thisUriEvtVector.firstElement();
//                                System.out.println("###########boucle k "+otherEvent3);
                                updateGui(otherEvent3, uri, _diffDetected);
                                thisUriEvtVector.remove(0);
                            }

                            _diffDetected = false;

                            otherUriEvtVector.remove(otherEvent2);
//                            System.out.println("otherevent2 "+otherEvent2);
//                            System.out.println("event "+event);
                            updateGui(otherEvent2, otherUri, _diffDetected);
                            updateGui(event, uri, _diffDetected);

                        } // end if
                    } // end for

                    if (_diffDetected) {
                        thisUriEvtVector.add(event);
                    }

                } // end if (end of the tricky code)


            } else {

                otherUriEvtVector.remove(otherEvent);
                updateGui(otherEvent, otherUri, _diffDetected);
                updateGui(event, uri, _diffDetected);

            } // end if


        } // end if

        notifyAll();
        return !_diffDetected;
    }

    /**
     * Update the gui model.
     *
     * @param event         the event to show in the gui
     * @param uri           the uri of the doc from where
     *                      the event comes.
     * @param diffdetected  A flag that indicate if a difference
     *                      has been detected with the event.
     */
    public synchronized void updateGui(Event event,
                                       String uri,
                                       boolean diffdetected) {

        XMLTreeModel tree = (XMLTreeModel) _treeGuiTable.get(uri);
        if (diffdetected) _diffcounter++;
        if (tree!=null) {
            tree.addNode(event,diffdetected);
        }

    }

    /**
     *
     */
    public void finishUnsuccessfull() {
        _diffDetected = true;
        synchronized(this) {
            notifyAll();
        }
    }


    /**
     * compare 2 xml documents
     * @param uri1  the uri of the first document
     * @param uri2  the uri of the second document
     * @return The number of differences detected
     */
    public int doCompare(String uri1, String uri2) {

        if (uri1.equals(uri2))
            return _diffcounter;

        _evtVectorTable.put(uri1,new Vector());
        _evtVectorTable.put(uri2,new Vector());

        _uriTable.put(uri1,uri2);
        _uriTable.put(uri2,uri1);


        SaxHandler handler1 = new SaxHandler(this,uri1);
        SaxHandler handler2 = new SaxHandler(this,uri2);
        handler1.setStopAtFirstDiff(_stopAtFirstDiff);
        handler2.setStopAtFirstDiff(_stopAtFirstDiff);


        Thread t1 = new ParserWorker(uri1,this,handler1);
        Thread t2 = new ParserWorker(uri2,this,handler2);

        t1.start();
        t2.start();

        while(t1.isAlive()||t2.isAlive()) {
            synchronized(this) {
                try {
                    wait(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

//        System.out.println(uri1+" "+((Vector)_evtVectorTable.get(uri1)).size());
//        System.out.println(uri2+" "+((Vector)_evtVectorTable.get(uri2)).size());

        return _diffcounter;

    }


    public static void main(String[] argv) {
        if (argv.length != 2) {
            System.out.println("Usage: java SaxComparator [URI1] [URI2]");
            System.exit(0);
        }


        String uri1 = argv[0];
        String uri2 = argv[1];

        SaxComparator comparator = new SaxComparator();



        int nbdiff = comparator.doCompare(uri1,uri2);
        if (nbdiff==0) {
            System.out.println(uri1+" and "+uri2+" seem to be equivalent");
        } else {
            System.out.println(nbdiff+" differences were detected between "+uri1+" and "+uri2);
        }


    }


}





