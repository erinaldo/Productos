package org.xmlcomparator;

import  java.io.IOException;
import  org.xml.sax.SAXException;
import  org.xml.sax.XMLReader;
import  org.xml.sax.helpers.XMLReaderFactory;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */

public class ParserWorker extends Thread {

    String _uri = "";
    SaxComparator _comparator = null;
    SaxHandler _handler = null;

    /**
     *
     * @param uri
     * @param comparator
     * @param handler
     */
    public ParserWorker(String uri, SaxComparator comparator, SaxHandler handler) {
        _uri = uri;
        _comparator = comparator;
        _handler = handler;
    }

    /**
     * Initialise the xerces parser and launch the parsing
     */
    public void run() {
        try {
            XMLReader parser = XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
            parser.setContentHandler(_handler);
            parser.setErrorHandler(_handler);
            parser.parse(_uri);
        } catch(IOException ioe) {
            ioe.printStackTrace();
            _comparator.finishUnsuccessfull();
        } catch(SAXException saxe) {
//            saxe.printStackTrace();
            _comparator.finishUnsuccessfull();
        }
    }

}