package org.xmlcomparator.saxEvents;

import org.xml.sax.Attributes;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */

public class StartElement extends Event {

    String _uri = "";
    String _localName = "";
    String _qName = "";
    Attributes _attributes = null;

    public String getUri() {
        return _uri;
    }
    public String getLocalName() {
        return _localName;
    }
    public String getQName() {
        return _qName;
    }
    public Attributes getAttributes() {
        return _attributes;
    }




    public StartElement(String uri, String localName, String qName, Attributes attributes, int depth) {
        _uri = uri;
        _localName = localName;
        _qName = qName;
        _attributes = attributes;

        setDepth(depth);
    }

    public boolean compare(Event event) {
        if (!(event instanceof StartElement)||!compareDepth(event))
            return false;
        return compareValues(event);
    }

    boolean compareValues(Event event) {
        StartElement startElement = (StartElement)event;

        return (_uri.equals(startElement.getUri())
                &&_localName.equals(startElement.getLocalName())
                &&_qName.equals(startElement.getQName())
                &&compareAttributes(startElement.getAttributes()));
    }

    boolean compareAttributes(Attributes att) {

        if (att==null) System.out.println("#################################");

        int nbAttributes = _attributes.getLength();

        // different numbers of attributes
        if ( att.getLength() != nbAttributes )
            return false;

        for( int i=0; i<nbAttributes; i++ ) {
            String attributeName = _attributes.getQName(i);
            String attributeValue =  att.getValue(attributeName);

//            System.out.println(attributeName+" : "+attributeValue);
//            System.out.println(attributeName+" : "+_attributes.getValue(i));
            // the attribute doesnt exist
            if (attributeValue==null) return false;

            boolean test = attributeValue.equals(_attributes.getValue(i));

            // the 2 attributes dont have the same value
            if (!test) return false;
        }

        return true;
    }

    public String  toString() {
        StringBuffer output = new StringBuffer("<");
        output.append(_qName);

        int nbAttributes = _attributes.getLength();
        for( int i=0; i<nbAttributes; i++ ) {
            output.append(" ");
            output.append(_attributes.getQName(i));
            output.append("=\"");
            output.append(_attributes.getValue(i));
            output.append("\"");
        }
        output.append(">");

        return output.toString();
    }

    public String getType() {
        return "[start element]";
    }

}