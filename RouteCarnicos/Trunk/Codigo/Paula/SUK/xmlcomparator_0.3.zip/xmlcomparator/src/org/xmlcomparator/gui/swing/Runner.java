package org.xmlcomparator.gui.swing;

import javax.swing.UIManager;
import java.awt.*;

/**
 * <p>The runner class</p>
 * <p>This class has a lmain method that lauch the application</p>
 * <p> </p>
 * <p> </p>
 * @author  Alexandre Victoor
 * @version 1.0
 */

public class Runner {
    boolean packFrame = false;

    //Construct the application
    public Runner() {
        Frame1 frame = new Frame1();
        //Validate frames that have preset sizes
        //Pack frames that have useful preferred size info, e.g. from their layout
        if (packFrame) {
            frame.pack();
        }
        else {
            frame.validate();
        }

        frame.setSize(400,500);

        //Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();

        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        frame.setVisible(true);
    }
    //Main method
    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        new Runner();
    }
}