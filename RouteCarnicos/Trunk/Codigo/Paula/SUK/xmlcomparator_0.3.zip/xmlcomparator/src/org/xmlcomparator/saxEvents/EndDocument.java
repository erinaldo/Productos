package org.xmlcomparator.saxEvents;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */

public class EndDocument extends Event {

    public EndDocument(int depth) {
        setDepth(depth);
    }
    public boolean compare(Event event) {
        return ((event instanceof EndDocument)&&compareDepth(event));
    }

    public String  toString() {
        return "";
    }
    public String getType() {
        return "[end document]";
    }

}