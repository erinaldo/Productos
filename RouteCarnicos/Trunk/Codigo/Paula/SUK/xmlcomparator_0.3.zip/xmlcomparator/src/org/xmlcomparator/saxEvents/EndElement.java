package org.xmlcomparator.saxEvents;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */

public class EndElement extends Event {

    String _uri = "";
    String _localName = "";
    String _qName = "";
//    String _value = "";

    public String getUri() {
        return _uri;
    }
    public String getLocalName() {
        return _localName;
    }
    public String getQName() {
        return _qName;
    }
//    public String getValue() {
//        return _value;
//    }


    public EndElement(String uri, String localName, String qName, int depth) {
        _uri = uri;
        _localName = localName;
        _qName = qName;
//        _value = value;

        setDepth(depth);
    }

    public boolean compare(Event event) {
        if (!(event instanceof EndElement)||!compareDepth(event))
            return false;
        return compareValues(event);
    }

    boolean compareValues(Event event) {
        EndElement endElement = (EndElement)event;
        return (_uri.equals(endElement.getUri())
                &&_localName.equals(endElement.getLocalName())
                &&_qName.equals(endElement.getQName()));
//                &&_value.equals(endElement.getValue()));
    }

    public String  toString() {
        return "</"+_qName+">";
    }

    public String getType() {
        return "[end element]";
    }


}