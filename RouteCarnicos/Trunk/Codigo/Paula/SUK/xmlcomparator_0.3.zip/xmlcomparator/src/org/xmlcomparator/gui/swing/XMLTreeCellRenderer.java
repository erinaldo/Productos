package org.xmlcomparator.gui.swing;

import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JTree;
import  java.awt.Component;
import  java.awt.Color;

/**
 * <p>Tree Renderer.</p>
 * <p> Renderer of the tree representation of the
 * XML documents</p>
 * <p> </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */
public class XMLTreeCellRenderer extends DefaultTreeCellRenderer {

    /**
     * The renderer method.
     * The text color in the tree is changed here,
     * depending of the differences detected before.
     *
     * @param tree
     * @param value
     * @param sel
     * @param expanded
     * @param leaf
     * @param row
     * @param hasFocus
     * @return
     */
    public Component getTreeCellRendererComponent(
                        JTree tree,
                        Object value,
                        boolean sel,
                        boolean expanded,
                        boolean leaf,
                        int row,
                        boolean hasFocus) {

        boolean diffdetected =
            ((XMLTreeNode)((DefaultMutableTreeNode)value).getUserObject()).isDiff();

        if (diffdetected) {
            setTextNonSelectionColor(Color.red);
        } else {
            setTextNonSelectionColor(Color.blue);
        }

        super.getTreeCellRendererComponent(
                        tree, value, sel,
                        expanded, leaf, row,
                        hasFocus);

        return this;


    }
}