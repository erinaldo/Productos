package org.xmlcomparator.gui.swing;

import  org.xmlcomparator.saxEvents.Event;

import  java.util.HashMap;
import  java.util.StringTokenizer;

/**
 *
 * <p>XML node representation.</p>
 * <p>All the user objects in the swing tree
 * have to be instances of this class.
 * Here an event an a boolean (diidetected)
 * are encapsulated. A static method deals
 * also with the printing of the value of the
 * event in the tree.</p>
 *
 * @author unascribed
 * @version 1.0
 */
public class XMLTreeNode {

    private Event   _saxEvt          = null;
    private boolean _diffDetected    = false;

    static HashMap _tokenMap = new HashMap();
    static {
        _tokenMap.put("\n","\\n");
        _tokenMap.put("\r","\\r");
        _tokenMap.put("\t","\\t");
    }

    /**
     * Base constructor
     * @param evt   the sax event representation
     * @param diff  true if a diff has been detected
     */
    public XMLTreeNode(Event evt, boolean diff) {
        _saxEvt = evt;
        _diffDetected = diff;
    }

    /**
     * toString method used in the swing tree
     * @return  the value of the event.
     */
    public String toString() {
        return slashNFormater(_saxEvt.toString());
    }

    /**
     * @return return true if a diff has been detected
     */
    public boolean isDiff() {
        return _diffDetected;
    }

    /**
     * Removes the special characters \n \r \t
     * @param input
     * @return
     */
    public static String slashNFormater( String input ) {

        if (input.equals("")) return "[EMPTY]";

        StringTokenizer tokenizer = new StringTokenizer(input,"\n\r\t",true);
        StringBuffer output = new StringBuffer();



        while(tokenizer.hasMoreTokens()) {
            output.append(formatToken(tokenizer.nextElement()));
        }

        return output.toString();

    }

    /**
     * Utility method for slashNFormater()
     * @param t
     * @return
     */
    private static String formatToken(Object t) {
        if (_tokenMap.containsKey(t)) {
            return (String)_tokenMap.get(t);
        } else {
            return (String)t;
        }
    }




}