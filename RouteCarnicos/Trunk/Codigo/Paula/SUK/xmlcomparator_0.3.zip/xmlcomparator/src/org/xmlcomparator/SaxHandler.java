package org.xmlcomparator;

import  org.xml.sax.helpers.DefaultHandler;
import  org.xml.sax.helpers.AttributesImpl;
import  org.xml.sax.SAXException;
import  org.xml.sax.SAXParseException;
import  org.xml.sax.Attributes;

import  org.xmlcomparator.saxEvents.Event;
import  org.xmlcomparator.saxEvents.StartDocument;
import  org.xmlcomparator.saxEvents.StartElement;
import  org.xmlcomparator.saxEvents.EndDocument;
import  org.xmlcomparator.saxEvents.EndElement;
import  org.xmlcomparator.saxEvents.Characters;



/**
 * <p>The handler of the sax ecvents</p>
 *
 * <p>This is a sax handler used by the two workers
 *  that parses the 2 documents to compare. Each time
 *  an event is detected, the compare method of the
 *  class SaxComparator is called. </p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */

public class SaxHandler extends DefaultHandler {

    private SaxComparator _comparator;
    private StringBuffer _charbuff = new StringBuffer();
//    private java.util.Stack _buffstack = new java.util.Stack();

    /** uri of the xml document */
    private String _uri ="";

    /** current depth in the tree */
    private int _depth = 0;

    /** flag that indicate if we stop at the first difference detected */
    private boolean _stopAtFirstDiff = true;

    /**
     * Default constructor.
     * @param   comparator the comparator used to compare the events
     *          comming from the 2 documents.
     */
    public SaxHandler( SaxComparator comparator, String uri) {
        _comparator = comparator;
        _uri = uri;
    }

    public boolean getStopAtFirstDiff() {
        return _stopAtFirstDiff;
    }

    public void setStopAtFirstDiff(boolean stopAtFirstDiff) {
        _stopAtFirstDiff = stopAtFirstDiff;
    }



    /**
     * Put the characters in a buffer for later use.
     * @param ch
     * @param start
     * @param length
     * @throws SAXException
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        _charbuff.append(ch,start,length);
    }

    /**
     * Does nothing right now.
     * @param ch
     * @param start
     * @param length
     * @throws SAXException
     */
    public void ignorableWhitespace (char ch[], int start, int length) throws SAXException {

    }

    /**
     *
     * @throws SAXException
     */
    public void endDocument() throws SAXException {
        if (!_comparator.compareEvent(new EndDocument(_depth),_uri)) {
            if (_stopAtFirstDiff)
                throw (new SAXException("the two documents dont have the same size"));
        }
    }

    /**
     * Treatement of the end element event.
     *
     *
     * @param uri
     * @param localName
     * @param qName
     * @throws SAXException
     */
    public void endElement(String uri, String localName, String qName) throws SAXException {

        if (!_comparator.compareEvent(new Characters(_charbuff.toString(),_depth),_uri)) {
            if (_stopAtFirstDiff)
                throw (new SAXException("difference detected (element "
                                        +localName+" with the text)"));
        }
        _charbuff = new StringBuffer();
        _depth--;
        if (!_comparator.compareEvent(new EndElement(uri,localName,qName,_depth),_uri)) {
            if (_stopAtFirstDiff)
                throw (new SAXException("difference detected (element "
                                        +localName+")"));
        }
//        if (!_buffstack.empty())
//            _charbuff = (StringBuffer) _buffstack.pop();

    }

    /**
     *
     * @throws SAXException
     */
    public void startDocument() throws SAXException {
        if (!_comparator.compareEvent(new StartDocument(_depth),_uri)) {
            if (_stopAtFirstDiff)
                throw (new SAXException("difference detected at the beginning of the document"));
        }
    }

    /**
     * Treatement of the start element event.
     * A new string buffer is instantiated here
     * to put the characters comming from a new XML
     * element. The older buffer containing the
     * characters of the parent element is push in a
     * stack trace for later use.
     *
     * @param uri
     * @param localName
     * @param qName
     * @param attributes
     * @throws SAXException
     */
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
//        if (_charbuff!=null)
//            _buffstack.push(_charbuff);
        if (_charbuff.length()>0) {
            if (!_comparator.compareEvent(new Characters(_charbuff.toString(),_depth),_uri)) {
                if (_stopAtFirstDiff)
                    throw (new SAXException("difference detected (element "
                                            +localName
                                            +" with the text)"));
            }
            _charbuff = new StringBuffer();
        }

        if (!_comparator.compareEvent(
                        new StartElement(uri,
                                         localName,
                                         qName,
                                         new AttributesImpl(attributes), //clone the attributes
                                         _depth),
                        _uri)) {

            if (_stopAtFirstDiff)
                throw (new SAXException("difference detected (element "
                                        +localName
                                        +")"));
        }
        _depth++;
    }

    /**
     *
     * @param e
     * @throws SAXException
     */
    public void fatalError(SAXParseException e) throws SAXException {
        System.err.println("Fatal error detected (can't work on non XML-files)");
    }

}