package org.xmlcomparator.gui.swing;

import  java.io.File;
import  javax.swing.filechooser.FileFilter;

/**
 * <p>an XML file filter.</p>
 * <p>This is used in the open dialog windows</p>
 * <p> </p>
 * @author Alexandre Victoor
 * @version 1.0
 */
public class XMLFileFilter extends FileFilter {

    public XMLFileFilter() {
    }

    /**
     * The method used by the Gui.
     * @param f the file that could be an XML file
     * @return  true if it is an xml file
     */
    public boolean accept(File f) {
        if (f.isDirectory()) {
            return true;
        }

        String ext = getExtension(f);
        if (ext==null) return false;
        return ext.equalsIgnoreCase("xml")||
                ext.equalsIgnoreCase("xsl")||
                ext.equalsIgnoreCase("xsd");
    }

    public static String getExtension(File f) {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');
        if (i > 0 &&  i < s.length() - 1) {
            ext = s.substring(i+1).toLowerCase();
        }
        return ext;
    }

    public String getDescription() {
        return "XML files ( *.xml, *.xsl, *.xsd )";
    }
}