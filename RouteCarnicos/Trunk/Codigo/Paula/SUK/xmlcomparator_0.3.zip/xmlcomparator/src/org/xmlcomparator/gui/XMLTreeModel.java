package org.xmlcomparator.gui;

import  org.xmlcomparator.saxEvents.Event;

/**
 * <p>Title: XMLCompare</p>
 * <p>Description: A tool to compare 2 XML documents using SAX</p>
 * <p> </p>
 * <p> </p>
 * @author unascribed
 * @version 1.0
 */

public interface XMLTreeModel {

    public void addNode(Event event, boolean diffDetected);

}